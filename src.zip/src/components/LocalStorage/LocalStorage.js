const addToDb = id => {
    localStorage.setItem(id, 1);
}
export {addToDb};